# Besties-Help
PreCell
# Bestie Helping Hands Adult Day Program Website

This is the static website for **Bestie Helping Hands Adult Day Program**, an adult day program supporting autistic adults ages 18–40 in Cincinnati, Ohio.  

## Features
- Bright brand colors (red, green, yellow, blue)  
- Responsive layout for mobile and desktop  
- Image gallery and videos  
- Contact form that opens the user’s email client  
- Simple navigation menu  

## Deployment
This site is a static build (HTML, CSS, JS, and assets).  
It can be hosted on:
- **Netlify** – drag and drop the project folder  
- **Vercel** – upload folder or connect GitHub repo  
- **GitHub Pages** – enable Pages in repository settings  

## Folder Structure
index.html
styles.css
app.js
assets/
├ bestieslogo.png
├ founder-charlotte.jpg
├ gallery-1.jpg
├ gallery-2.jpg
├ gallery-3.jpg
├ gallery4.jpg
├ gallery5.jpg
└ founders.JPG

## Contact
- Phone: (513) 302-2216  
- Email: CharlotteBest503605@gmail.com  
- Address: Mid City Center, 1821 Summit Rd, Suite 203, Cincinnati, OH 45237  
- Hours: Monday – Friday, 8:00 AM – 6:00 PM  

